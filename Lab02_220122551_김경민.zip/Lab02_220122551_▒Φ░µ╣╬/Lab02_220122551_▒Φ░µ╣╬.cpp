﻿// Lab02_220122551_김경민.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include "pch.h"
#include "framework.h"
#include "Lab02_220122551_김경민.h"
#include <iostream>
#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 유일한 애플리케이션 개체입니다.

CWinApp theApp;

using namespace std;

int main()
{
    int nRetCode = 0;

    HMODULE hModule = ::GetModuleHandle(nullptr);

    if (hModule != nullptr)
    {
        // MFC를 초기화합니다. 초기화하지 못한 경우 오류를 인쇄합니다.
        if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0))
        {
            // TODO: 여기에 애플리케이션 동작을 코딩합니다.
            wprintf(L"심각한 오류: MFC 초기화 실패\n");
            nRetCode = 1;
        }
        else
        {
            // TODO: 여기에 애플리케이션 동작을 코딩합니다.

            int op_pos; // 연산자 위치
            double x, y;
            double result = 0;
            CString op("+ - * /"); // 사칙연산 연산자 CString에 저장
            CString Left, Right;

            CString str; // 문자열을 CString으로 선언
             _tsetlocale(LC_ALL, _T("")); // Console에서 한글(유니코드)을 출력
            str = _T("사칙연산 수식을 입력하시오 : "); // 사칙연산 수식 입력 문구
            _tprintf(_T("%s\n"), str); // 출력

            string input; // string 문자열 선언
            getline(cin, input); // 문자열 입력받기

            CString formula(input.c_str()); // CString formula에 input 저장
            formula.Replace(_T(" "), NULL); // CString에서 문자열 사이 공백 제거

            op_pos = formula.FindOneOf(op);// 연산자의 위치 찾고 반환.
            Left = formula.Left(op_pos); // 연산자 기준 왼쪽
            Right = formula.Right(formula.GetLength() - (op_pos + 1)); // 연산자 기준 오른쪽
            x = _tstof(Left); // 첫 번째 숫자 저장
            y = _tstof(Right); // 두 번째 숫자 저장

            if (formula.FindOneOf(_T("+")) == op_pos) // '+' 연산자를 찾았을 때
            {
                result = x + y; // 더하기
            }
            else if (formula.FindOneOf(_T("-")) == op_pos) // '-' 연산자를 찾았을 때
            {
                result = x - y; // 빼기
            } 
            else if (formula.FindOneOf(_T("*")) == op_pos) // '*' 연산자를 찾았을 때
            {
                result = x * y; // 곱하기
            }
            else if (formula.FindOneOf(_T("/")) == op_pos) // '/' 연산자를 찾았을 때
            {
                result = x / y; // 나누기
            }
            else 
            {
                _tprintf(_T("Error !!!\n"));
            }
            _tprintf(_T("%lf\n"), result); // 연산 결과 출력
        }
    }
    else
    {
        // TODO: 오류 코드를 필요에 따라 수정합니다.
        wprintf(L"심각한 오류: GetModuleHandle 실패\n");
        nRetCode = 1;
    }

    return nRetCode;
}
