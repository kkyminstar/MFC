﻿
// ChildView.cpp: CChildView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
#include "CClientDC_Lab04.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()



// CChildView 메시지 처리기

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), nullptr);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.
	
	// TODO: 여기에 메시지 처리기 코드를 추가합니다.
	
	// 그리기 메시지에 대해서는 CWnd::OnPaint()를 호출하지 마십시오.

	for (int i = 1; i < arr.GetSize(); i++) 
	{ 
		dc.Rectangle(arr[i].x - 20, arr[i].y - 20, arr[i].x + 20, arr[i].y + 20); // 1번 index부터 사각형 다시 그리기
	}
}



void CChildView::OnLButtonDown(UINT nFlags, CPoint point) // 마우스 왼쪽 버튼
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	// CWnd::OnLButtonDown(nFlags, point);

	CClientDC dc(this);
	dc.Rectangle(point.x - 20, point.y - 20, point.x + 20, point.y + 20); // 각 변의 길이가 40인 사각형 그리기
	arr.InsertAt(nFlags, point); // 사각형의 위치좌표를 arr에 저장
}


void CChildView::OnRButtonDown(UINT nFlags, CPoint point) // 마우스 오른쪽 버튼
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	// CWnd::OnRButtonDown(nFlags, point);

	for (int i = 1; i < arr.GetSize(); i++) 
	{
		if (((point.x > arr[i].x - 20) && (point.x < arr[i].x + 20)) && ((point.y > arr[i].y - 20) && (point.y < arr[i].y + 20))) // 사각형 내부이면
		{
			arr.RemoveAt(i); // 해당 사각형을 삭제함
		}
	}
	Invalidate(); // 윈도우 무효화(해당 윈도우의 내용이 변경되었음을 알림) - 다시 그리기
}
